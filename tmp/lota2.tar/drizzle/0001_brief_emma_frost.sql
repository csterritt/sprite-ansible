DROP INDEX `longer_description_idx`;--> statement-breakpoint
ALTER TABLE `event` DROP COLUMN `longer_description`;